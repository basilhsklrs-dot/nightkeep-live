package com.yaahua.vcam.live;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.SurfaceTexture;
import android.view.Surface;
import android.view.TextureView;
import android.widget.*;
import com.yaahua.vcam.SharedState;

/** Exercises the real decoder with replacement and resized outputs, without TikTok. */
public final class CameraOutputTestActivity extends Activity {
    private LinearLayout root;
    private TextureView preview;
    private Surface target;
    private TextView status;
    private boolean wide;
    private int generation;
    private final Handler main=new Handler();
    private final Runnable poll=new Runnable(){public void run(){status.setText("LOCAL OUTPUT TEST — NOT TIKTOK\nOutput generation: "+generation+" · "+(wide?"landscape":"portrait")+"\nSource frames: "+LivePackets.frames+" · pipe clients: "+LivePackets.clientCount()+"\n"+LivePackets.status+"\nStart the live game source first. Recreate and resize should restore the picture. Raw camera rotation may differ from TikTok.");main.postDelayed(this,1000);}};
    @Override public void onCreate(Bundle state){super.onCreate(state);SharedState.toast_content=this;root=new LinearLayout(this);root.setOrientation(1);root.setPadding(18,24,18,16);status=new TextView(this);root.addView(status);
        Button recreate=new Button(this);recreate.setText("RECREATE OUTPUT");recreate.setOnClickListener(v->createPreview());root.addView(recreate);
        Button resize=new Button(this);resize.setText("PORTRAIT / LANDSCAPE OUTPUT");resize.setOnClickListener(v->{wide=!wide;createPreview();});root.addView(resize);setContentView(root);createPreview();main.post(poll);
    }
    private void detach(){if(target!=null){LiveCamera.detach(target);target.release();target=null;}}
    private void createPreview(){detach();if(preview!=null)root.removeView(preview);generation++;preview=new TextureView(this);root.addView(preview,new LinearLayout.LayoutParams(-1,wide?320:560));preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
        private Surface owned;
        public void onSurfaceTextureAvailable(SurfaceTexture texture,int width,int height){owned=new Surface(texture);target=owned;LiveCamera.surface(owned);}
        public void onSurfaceTextureSizeChanged(SurfaceTexture texture,int width,int height){}
        public boolean onSurfaceTextureDestroyed(SurfaceTexture texture){if(owned!=null){LiveCamera.detach(owned);owned.release();if(target==owned)target=null;owned=null;}return true;}
        public void onSurfaceTextureUpdated(SurfaceTexture texture){}
    });}
    @Override protected void onDestroy(){main.removeCallbacks(poll);detach();SharedState.toast_content=null;super.onDestroy();}
}
