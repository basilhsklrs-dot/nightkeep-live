package com.yaahua.vcam.live;

import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.widget.*;
import com.yaahua.vcam.ConfigManager;

public final class LiveGameActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView status;
    private final Runnable refresh=new Runnable() { public void run() {
        status.setText(LivePackets.status+"\nEncoded frames: "+LivePackets.frames+"\nConnected camera outputs: "+LivePackets.clientCount()+"\nLast frame age: "+(LivePackets.lastFrameAt==0?"—":(android.os.SystemClock.elapsedRealtime()-LivePackets.lastFrameAt)+" ms")+"\n\nAfter starting, force-stop and reopen patched TikTok. Test preview before going LIVE.\n\nExperimental: video only. Game sound is not sent to TikTok."); handler.postDelayed(this,1000);
    }};
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(32,40,32,20);
        TextView title=new TextView(this); title.setText("NIGHTKEEP • Live camera TEST4"); title.setTextSize(23); box.addView(title);
        EditText url=new EditText(this); url.setSingleLine(true); url.setText(getPreferences(0).getString("url","https://nightkeep-live.onrender.com")); box.addView(url);
        TextView hint=new TextView(this);hint.setText("Camera correction (Stop then Start after a change)");box.addView(hint);
        Spinner rotation=new Spinner(this);rotation.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Tablet: counter-clockwise 90° (recommended)","No correction","Clockwise 90°","180°"}));
        rotation.setSelection(getPreferences(0).getInt("rotationIndex",0));box.addView(rotation);
        Button start=new Button(this); start.setText("Start live game source"); box.addView(start);
        start.setOnClickListener(v -> {
            String address=url.getText().toString().trim();
            if(!address.startsWith("https://")) { url.setError("Use an HTTPS game URL"); return; }
            getPreferences(0).edit().putString("url",address).apply();
            ConfigManager config=new ConfigManager(); config.setBoolean("nightkeep_live",true); config.setBoolean(ConfigManager.KEY_DISABLE_MODULE,false);
            int index=rotation.getSelectedItemPosition();getPreferences(0).edit().putInt("rotationIndex",index).apply();
            Intent service=new Intent(this,LiveGameService.class).putExtra("url",address).putExtra("rotation",new int[]{270,0,90,180}[index]);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(service); else startService(service);
        });
        Button stop=new Button(this); stop.setText("Stop and restore saved video"); box.addView(stop);
        stop.setOnClickListener(v -> { new ConfigManager().setBoolean("nightkeep_live",false); stopService(new Intent(this,LiveGameService.class)); });
        Button test=new Button(this);test.setText("Test camera outputs (no TikTok)");test.setOnClickListener(v->startActivity(new Intent(this,CameraOutputTestActivity.class)));box.addView(test);
        status=new TextView(this); status.setTextSize(17); box.addView(status); setContentView(box);
    }
    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
}
