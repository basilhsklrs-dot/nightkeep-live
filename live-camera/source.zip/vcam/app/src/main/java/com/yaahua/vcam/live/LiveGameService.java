package com.yaahua.vcam.live;

import android.app.*;
import android.content.*;
import android.hardware.display.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.FrameLayout;
import java.nio.ByteBuffer;

/** Renders the real game in a hardware WebView on an encoder-backed display. */
public final class LiveGameService extends Service {
    private MediaCodec encoder;
    private Surface input;
    private VirtualDisplay display;
    private Presentation presentation;
    private WebView web;
    private volatile boolean running;
    private android.os.PowerManager.WakeLock wake;
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(running) return START_NOT_STICKY;
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("nightkeep-live","Nightkeep live source",NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,LiveGameService.class).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"nightkeep-live"):new Notification.Builder(this);
        startForeground(42,nb.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("NIGHTKEEP live browser")
            .setContentText("Game is running for the virtual camera. Tap Stop to end.")
            .addAction(new Notification.Action.Builder(null,"Stop",stop).build()).setOngoing(true).build());
        try {
            LivePackets.reset();
            String url=intent!=null?intent.getStringExtra("url"):null;
            if(url==null) url="https://nightkeep-live.onrender.com";
            if(!url.startsWith("https://")) throw new IllegalArgumentException("HTTPS game URL required");
            int rotation=intent!=null?intent.getIntExtra("rotation",270):270;
            boolean sideways=rotation==90||rotation==270;
            int encodeW=sideways?1280:720,encodeH=sideways?720:1280;
            encoder=MediaCodec.createEncoderByType("video/avc");
            MediaFormat format=MediaFormat.createVideoFormat("video/avc",encodeW,encodeH);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            format.setInteger(MediaFormat.KEY_BIT_RATE,2500000);
            format.setInteger(MediaFormat.KEY_FRAME_RATE,20);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);
            format.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER,50000);
            encoder.configure(format,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            input=encoder.createInputSurface(); encoder.start(); running=true;
            LivePackets.requestKeyFrame=()->{if(running&&encoder!=null){Bundle b=new Bundle();b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME,0);encoder.setParameters(b);}};
            display=getSystemService(DisplayManager.class).createVirtualDisplay("NIGHTKEEP",encodeW,encodeH,240,input,DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION|DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
            if(display==null) throw new IllegalStateException("Virtual display unavailable");
            presentation=new Presentation(this,display.getDisplay());
            web=new WebView(presentation.getContext());
            web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setMediaPlaybackRequiresUserGesture(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view,String page) {
                    LivePackets.status="Loaded: "+view.getTitle();
                    view.evaluateJavascript("(()=>{let n=0;const t=setInterval(()=>{const b=document.querySelector('#start');if(b&&typeof b.onclick==='function'){b.click();clearInterval(t);}else if(++n>40)clearInterval(t);},250);})()",null);
                }
                @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error) {
                    if(request.isForMainFrame()) LivePackets.status="Page error: "+error.getDescription();
                }
            });
            FrameLayout root=new FrameLayout(presentation.getContext());
            FrameLayout.LayoutParams layout=new FrameLayout.LayoutParams(720,1280,Gravity.CENTER);
            root.addView(web,layout);web.setRotation(rotation);
            presentation.setContentView(root); presentation.show(); web.loadUrl(url);
            wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"nightkeep:live"); wake.acquire(4*60*60*1000L);
            LivePackets.status="Loading game";
            new Thread(this::drain,"Nightkeep-encoder").start();
        } catch(Exception e) { LivePackets.status="Start failed: "+e.getMessage(); stopSelf(); }
        return START_NOT_STICKY;
    }
    private void drain() {
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        try {
            while(running) {
                int index=encoder.dequeueOutputBuffer(info,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) LivePackets.format(encoder.getOutputFormat());
                else if(index>=0) {
                    ByteBuffer buffer=encoder.getOutputBuffer(index);
                    if(buffer!=null && info.size>0) {
                        buffer.position(info.offset); buffer.limit(info.offset+info.size);
                        byte[] data=new byte[info.size]; buffer.get(data);
                        LivePackets.publish(data,info.presentationTimeUs,info.flags);
                    }
                    encoder.releaseOutputBuffer(index,false);
                }
            }
        } catch(Exception e) { if(running) { LivePackets.status="Encoder failed: "+e.getMessage(); new Handler(getMainLooper()).post(this::stopSelf); } }
        finally { try { encoder.stop(); encoder.release(); } catch(Exception ignored) {} }
    }
    @Override public void onDestroy() {
        running=false;
        if(web!=null) { web.stopLoading(); web.destroy(); web=null; }
        if(presentation!=null) presentation.dismiss();
        if(display!=null) display.release();
        if(input!=null) input.release();
        if(wake!=null && wake.isHeld()) wake.release();
        LivePackets.reset(); super.onDestroy();
    }
}
