package com.yaahua.vcam.live;

import java.nio.ByteBuffer;
import java.util.Arrays;

/** YUV planes may have padding, interleaved chroma and a nonzero buffer position. */
public final class FrameConverter {
    public static final class Plane {
        final ByteBuffer data; final int row,pixel,base;
        public Plane(ByteBuffer data,int row,int pixel) { this.data=data;this.row=row;this.pixel=pixel;this.base=data.position(); }
        byte at(int x,int y) { return data.get(base+y*row+x*pixel); }
    }
    public static byte[] convert(Plane[] planes,int cropLeft,int cropTop,int cropWidth,int cropHeight,int w,int h) {
        if(w<=0 || h<=0 || (w&1)!=0 || (h&1)!=0) throw new IllegalArgumentException("NV21 dimensions must be positive and even");
        byte[] out=new byte[w*h*3/2]; Arrays.fill(out,0,w*h,(byte)16); Arrays.fill(out,w*h,out.length,(byte)128);
        boolean rotate=(w>h)!=(cropWidth>cropHeight);
        int sourceW=rotate?cropHeight:cropWidth,sourceH=rotate?cropWidth:cropHeight;
        float scale=Math.min((float)w/sourceW,(float)h/sourceH);
        int drawW=((int)(sourceW*scale))&~1,drawH=((int)(sourceH*scale))&~1;
        int left=((w-drawW)/2)&~1,top=((h-drawH)/2)&~1;
        for(int y=0;y<drawH;y++) for(int x=0;x<drawW;x++) {
            int sx=Math.min(sourceW-1,(int)(x/scale)),sy=Math.min(sourceH-1,(int)(y/scale));
            int px=(rotate?cropWidth-1-sy:sx)+cropLeft,py=(rotate?sx:sy)+cropTop;
            out[(top+y)*w+left+x]=planes[0].at(px,py);
            if((x&1)==0 && (y&1)==0) {
                int p=w*h+((top+y)/2)*w+left+x;
                out[p]=planes[2].at(px/2,py/2); out[p+1]=planes[1].at(px/2,py/2);
            }
        }
        return out;
    }
}
