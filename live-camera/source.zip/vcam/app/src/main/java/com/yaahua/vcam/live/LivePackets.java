package com.yaahua.vcam.live;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.ParcelFileDescriptor;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.concurrent.*;

/** Local Binder pipes: no network listener or screen recording. */
public final class LivePackets {
    public static final int MAGIC = 0x4e4b4c31;
    private static final CopyOnWriteArrayList<Client> clients = new CopyOnWriteArrayList<>();
    private static volatile byte[] sps, pps;
    private static volatile int width=1280,height=720;
    public static volatile String status = "Stopped";
    public static volatile long frames;
    public static volatile long lastFrameAt;
    public static volatile Runnable requestKeyFrame;
    public static int clientCount(){return clients.size();}
    private static class Packet {
        final byte[] data; final long pts; final int flags;
        Packet(byte[] d, long p, int f) { data=d; pts=p; flags=f; }
    }
    private static class Client {
        final ArrayBlockingQueue<Packet> queue = new ArrayBlockingQueue<>(40);
        volatile boolean key;
        volatile ParcelFileDescriptor writer;
    }
    public static synchronized void format(MediaFormat f) {
        width=f.getInteger(MediaFormat.KEY_WIDTH);height=f.getInteger(MediaFormat.KEY_HEIGHT);
        sps=bytes(f.getByteBuffer("csd-0")); pps=bytes(f.getByteBuffer("csd-1"));
    }
    private static byte[] bytes(ByteBuffer b) {
        if (b==null) return new byte[0];
        ByteBuffer copy=b.duplicate(); byte[] a=new byte[copy.remaining()]; copy.get(a); return a;
    }
    public static void publish(byte[] data, long pts, int flags) {
        if ((flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0) return;
        frames++;lastFrameAt=android.os.SystemClock.elapsedRealtime();
        Packet packet=new Packet(data,pts,flags);
        for (Client c:clients) {
            if (!c.key) {
                if ((flags & MediaCodec.BUFFER_FLAG_KEY_FRAME)==0) continue;
                c.key=true;
            }
            if (!c.queue.offer(packet)) {
                clients.remove(c);
                try { c.writer.close(); } catch (Exception ignored) {}
            }
        }
    }
    public static ParcelFileDescriptor open() throws IOException {
        ParcelFileDescriptor[] pipe=ParcelFileDescriptor.createPipe();
        Client c=new Client(); c.writer=pipe[1]; clients.add(c);
        Runnable request=requestKeyFrame;if(request!=null)try{request.run();}catch(Exception ignored){}
        new Thread(() -> {
            try (DataOutputStream out=new DataOutputStream(new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]))) {
                long deadline=System.currentTimeMillis()+15000;
                while (sps==null && System.currentTimeMillis()<deadline) Thread.sleep(50);
                byte[] a=sps,b=pps;
                if(a==null || b==null) throw new IOException("Game encoder is not ready");
                out.writeInt(MAGIC); out.writeInt(width); out.writeInt(height);
                out.writeInt(a.length); out.write(a); out.writeInt(b.length); out.write(b); out.flush();
                while (clients.contains(c)) {
                    Packet p=c.queue.poll(5,TimeUnit.SECONDS);
                    if(p==null) throw new IOException("No live frames");
                    out.writeInt(p.data.length); out.writeLong(p.pts); out.writeInt(p.flags); out.write(p.data); out.flush();
                }
            } catch(Exception ignored) { } finally { clients.remove(c); }
        },"Nightkeep-pipe").start();
        return pipe[0];
    }
    public static synchronized void reset() {
        for(Client c:clients) try { c.writer.close(); } catch(Exception ignored) {}
        clients.clear(); sps=null; pps=null; frames=0;lastFrameAt=0;requestKeyFrame=null;status="Stopped";
    }
}
