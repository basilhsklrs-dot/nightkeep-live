package com.yaahua.vcam.live;

import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.media.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.view.Surface;
import com.yaahua.vcam.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

/** H264 decoder per camera Surface; bounded reconnect, no camera callback waits. */
public final class LiveCamera {
    private static final Map<Surface,Decoder> outputs=new HashMap<>();
    private static Decoder callbackDecoder;
    private static volatile byte[] nv21;
    private static volatile int callbackWidth,callbackHeight;
    public static boolean enabled() {
        return !HookGuards.isDisabled() && HookGuards.getConfig().getBoolean("nightkeep_live",false);
    }
    public static synchronized void surface(Surface target) {
        for(Iterator<Map.Entry<Surface,Decoder>> it=outputs.entrySet().iterator();it.hasNext();) {
            Map.Entry<Surface,Decoder> e=it.next();
            if(!e.getKey().isValid() || !e.getValue().isAlive()) { e.getValue().close(); it.remove(); }
        }
        if(target==null || !target.isValid() || outputs.containsKey(target)) return;
        android.util.Log.i("Nightkeep","Attach live camera output, count="+(outputs.size()+1));
        Decoder d=new Decoder(target,false); outputs.put(target,d); d.start();
    }
    public static synchronized void detach(Surface target) {
        Decoder decoder=outputs.remove(target);if(decoder!=null)decoder.close();
    }
    public static void preview(byte[] destination,Camera camera) {
        if(destination==null) return;
        Camera.Size size=camera.getParameters().getPreviewSize();
        synchronized(LiveCamera.class) {
            if(callbackDecoder==null || callbackWidth!=size.width || callbackHeight!=size.height) {
                if(callbackDecoder!=null) callbackDecoder.close();
                callbackWidth=size.width; callbackHeight=size.height; nv21=null;
                callbackDecoder=new Decoder(null,true); callbackDecoder.start();
            }
        }
        byte[] frame=nv21;
        if(frame!=null && frame.length<=destination.length) System.arraycopy(frame,0,destination,0,frame.length);
        else { // Never leak the physical camera while the game is connecting.
            Arrays.fill(destination,(byte)128);
            Arrays.fill(destination,0,Math.min(destination.length,size.width*size.height),(byte)16);
        }
    }
    public static synchronized void stop() {
        for(Decoder d:outputs.values()) d.close(); outputs.clear();
        if(callbackDecoder!=null) callbackDecoder.close(); callbackDecoder=null; nv21=null;
    }
    private static final class Decoder extends Thread {
        final Surface target; final boolean callback;
        volatile boolean active=true;
        long lastOutputAt;
        volatile ParcelFileDescriptor pipe;
        Decoder(Surface s,boolean c) { super("Nightkeep-camera"); target=s; callback=c; }
        void close() { active=false; interrupt(); try { if(pipe!=null) pipe.close(); } catch(Exception ignored) {} }
        public void run() {
            while(active) {
                MediaCodec codec=null;
                try {
                    if(SharedState.toast_content==null) throw new IOException("No camera context");
                    pipe=SharedState.toast_content.getContentResolver().openFileDescriptor(Uri.parse("content://com.nightkeep.livecamera.provider/nightkeep-live"),"r");
                    if(pipe==null) throw new IOException("No game stream");
                    try(DataInputStream in=new DataInputStream(new ParcelFileDescriptor.AutoCloseInputStream(pipe))) {
                        if(in.readInt()!=LivePackets.MAGIC) throw new IOException("Invalid stream header");
                        int w=in.readInt(),h=in.readInt();
                        if(!((w==720 && h==1280)||(w==1280 && h==720))) throw new IOException("Unexpected dimensions");
                        byte[] sps=read(in,65536),pps=read(in,65536);
                        MediaFormat f=MediaFormat.createVideoFormat("video/avc",w,h);
                        f.setByteBuffer("csd-0",ByteBuffer.wrap(sps));
                        if(pps.length>0) f.setByteBuffer("csd-1",ByteBuffer.wrap(pps));
                        if(callback) f.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
                        codec=MediaCodec.createDecoderByType("video/avc"); codec.configure(f,target,null,0); codec.start();lastOutputAt=android.os.SystemClock.elapsedRealtime();
                        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                        while(active) {
                            int n=in.readInt(); if(n<=0 || n>4000000) throw new IOException("Invalid packet size");
                            long pts=in.readLong(); int flags=in.readInt(); byte[] packet=new byte[n]; in.readFully(packet);
                            int index=codec.dequeueInputBuffer(10000);
                            if(index<0) { drain(codec,info); index=codec.dequeueInputBuffer(10000); }
                            if(index<0) throw new IOException("Decoder input stalled");
                            ByteBuffer input=codec.getInputBuffer(index);
                            if(input==null || input.capacity()<n) throw new IOException("Decoder packet too large");
                            input.clear(); input.put(packet); codec.queueInputBuffer(index,0,n,pts,flags);
                            drain(codec,info);
                            if(target!=null&&!target.isValid()) {active=false;break;}
                            if(android.os.SystemClock.elapsedRealtime()-lastOutputAt>5000)throw new IOException("No decoded frames for 5s");
                        }
                    }
                } catch(Exception e) { if(active) android.util.Log.w("Nightkeep","Live decoder reconnect: "+e); }
                finally { try { if(pipe!=null) pipe.close(); } catch(Exception ignored) {} pipe=null;
                    if(codec!=null) { try { codec.stop(); } catch(Exception ignored) {} try { codec.release(); } catch(Exception ignored) {} }
                }
                if(active) try { Thread.sleep(700); } catch(InterruptedException ignored) {}
            }
        }
        private byte[] read(DataInputStream in,int max) throws IOException {
            int n=in.readInt(); if(n<0||n>max) throw new IOException("Invalid codec header"); byte[] b=new byte[n]; in.readFully(b); return b;
        }
        private void drain(MediaCodec codec,MediaCodec.BufferInfo info) {
            int index;
            while((index=codec.dequeueOutputBuffer(info,0))>=0) {
                lastOutputAt=android.os.SystemClock.elapsedRealtime();
                try {
                    if(callback) {
                        Image image=codec.getOutputImage(index);
                        if(image!=null) try { nv21=convert(image,callbackWidth,callbackHeight); } finally { image.close(); }
                    }
                } finally { codec.releaseOutputBuffer(index,!callback); }
            }
        }
    }
    static byte[] convert(Image image,int w,int h) {
        android.graphics.Rect crop=image.getCropRect();
        Image.Plane[] source=image.getPlanes();
        FrameConverter.Plane[] planes=new FrameConverter.Plane[3];
        for(int i=0;i<3;i++) planes[i]=new FrameConverter.Plane(source[i].getBuffer(),source[i].getRowStride(),source[i].getPixelStride());
        return FrameConverter.convert(planes,crop.left,crop.top,crop.width(),crop.height(),w,h);
    }
}
