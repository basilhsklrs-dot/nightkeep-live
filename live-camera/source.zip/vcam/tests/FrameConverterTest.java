import com.yaahua.vcam.live.FrameConverter;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class FrameConverterTest {
    static void equal(byte[] a,int... expected) {
        byte[] b=new byte[expected.length];for(int i=0;i<b.length;i++)b[i]=(byte)expected[i];
        if(!Arrays.equals(a,b))throw new AssertionError(Arrays.toString(a));
    }
    public static void main(String[] args) {
        ByteBuffer y=ByteBuffer.wrap(new byte[]{99,1,2,0,0,3,4,0,0,5,6,0,0,7,8,0,0}); y.position(1);
        FrameConverter.Plane[] planes={new FrameConverter.Plane(y,4,1),new FrameConverter.Plane(ByteBuffer.wrap(new byte[]{10,0,0,0,20,0,0,0}),4,2),new FrameConverter.Plane(ByteBuffer.wrap(new byte[]{30,0,0,0,40,0,0,0}),4,2)};
        equal(FrameConverter.convert(planes,0,0,2,4,2,4),1,2,3,4,5,6,7,8,30,10,40,20);
        equal(FrameConverter.convert(planes,0,0,2,4,4,2),2,4,6,8,1,3,5,7,30,10,40,20);
        FrameConverter.Plane[] landscape={new FrameConverter.Plane(ByteBuffer.wrap(new byte[]{1,2,3,4,5,6,7,8}),4,1),new FrameConverter.Plane(ByteBuffer.wrap(new byte[]{10,20}),2,1),new FrameConverter.Plane(ByteBuffer.wrap(new byte[]{30,40}),2,1)};
        equal(FrameConverter.convert(landscape,0,0,4,2,4,2),1,2,3,4,5,6,7,8,30,10,40,20);
        byte[] letterbox=FrameConverter.convert(planes,0,0,2,4,4,8);
        if(letterbox.length!=48 || letterbox[0]!=1 || letterbox[3]!=2) throw new AssertionError("Scaling failed");
        try {FrameConverter.convert(planes,0,0,2,4,3,4);throw new AssertionError("Odd width accepted");}catch(IllegalArgumentException expected){}
        System.out.println("PASS: padded planes, buffer position, NV21 VU order, sensor rotation, scaling, invalid dimensions");
    }
}
